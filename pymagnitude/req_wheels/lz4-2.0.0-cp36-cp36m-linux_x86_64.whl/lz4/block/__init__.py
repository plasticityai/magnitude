from ._block import compress, decompress  # noqa: F401
